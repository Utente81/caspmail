import{c as n}from"./shield-check-COUKzgXV.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=n("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=n("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=n("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=n("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=n("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=n("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=n("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=n("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]);var l;const d=((l=window.__CASPERMAIL_CONFIG__)==null?void 0:l.keycloakIssuer)||"https://auth.secure.internal/realms/caspermail";let i=null;async function k(){const t=sessionStorage.getItem("caspmail_refresh_token"),e=sessionStorage.getItem("caspmail_client_id");if(!t||!e)throw new Error("No refresh token available");const r=await fetch(`${d}/protocol/openid-connect/token`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({grant_type:"refresh_token",client_id:e,refresh_token:t})});if(!r.ok)throw sessionStorage.removeItem("caspmail_access_token"),sessionStorage.removeItem("caspmail_refresh_token"),new Error("Refresh failed — please log in again");const a=await r.json();return sessionStorage.setItem("caspmail_access_token",a.access_token),a.refresh_token&&sessionStorage.setItem("caspmail_refresh_token",a.refresh_token),a.access_token}async function y(){const t=sessionStorage.getItem("caspmail_access_token");if(t)try{const{exp:e}=JSON.parse(atob(t.split(".")[1]));if(!e||e*1e3>Date.now()+6e4)return t}catch{}return i||(i=k().finally(()=>{i=null})),i}async function x(t,e={}){let r=await y();const a=o=>fetch(t,{...e,headers:{...e.headers,Authorization:`Bearer ${o}`}});let s=await a(r);return s.status===401&&(r=await k(),s=await a(r)),s}async function I(t,e={}){const r=await y(),a={"Content-Type":"application/json",...e.headers||{}};r&&(a.Authorization=`Bearer ${r}`);const s=await fetch(t,{...e,headers:a});if(!s.ok){let c="API Error";try{const h=await s.json();c=h.error||h.message||c}catch{c=`Status ${s.status}`}throw new Error(c)}const o=s.headers.get("content-type");return o&&o.includes("application/json")?s.json():s.text()}export{f as C,u as L,_ as P,w as R,g as T,M as U,v as a,m as b,x as c,y as e,I as f};
