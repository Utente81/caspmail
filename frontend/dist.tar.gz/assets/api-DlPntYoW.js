import{c as d}from"./shield-check-COUKzgXV.js";import{e as f}from"./tokenRefresh-Cxd1C_Mr.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=d("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=d("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=d("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=d("LockOpen",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 9.9-1",key:"1mm8w8"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=d("Save",[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=d("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]]),g="caspmail_e2ee",u="keys";function w(){return new Promise((t,n)=>{const a=indexedDB.open(g,1);a.onupgradeneeded=e=>e.target.result.createObjectStore(u),a.onsuccess=e=>t(e.target.result),a.onerror=()=>n(a.error)})}function h(){return sessionStorage.getItem("caspmail_user_email")||"main"}async function S(t){const n=await w();return new Promise((a,e)=>{const r=n.transaction(u,"readwrite");r.objectStore(u).put(t,h()),r.oncomplete=a,r.onerror=()=>e(r.error)})}async function k(){const t=await w();return new Promise((n,a)=>{const r=t.transaction(u,"readonly").objectStore(u).get(h());r.onsuccess=()=>n(r.result||null),r.onerror=()=>a(r.error)})}async function K(){const t=await w();return new Promise((n,a)=>{const e=t.transaction(u,"readwrite");e.objectStore(u).delete(h()),e.oncomplete=n,e.onerror=()=>a(e.error)})}async function P(){return await crypto.subtle.generateKey({name:"RSA-OAEP",modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:"SHA-256"},!0,["encrypt","decrypt"])}async function C(t){const n=await crypto.subtle.exportKey("spki",t);return`-----BEGIN PUBLIC KEY-----
${btoa(String.fromCharCode(...new Uint8Array(n))).match(/.{1,64}/g).join(`
`)}
-----END PUBLIC KEY-----`}async function v(t){const n=await crypto.subtle.exportKey("spki",t),a=await crypto.subtle.digest("SHA-256",n);return Array.from(new Uint8Array(a)).map(e=>e.toString(16).padStart(2,"0")).join(":").slice(0,47)}async function E(t){const n=t.replace(/-----[^-]+-----/g,"").replace(/\s/g,""),a=Uint8Array.from(atob(n),e=>e.charCodeAt(0));return crypto.subtle.importKey("spki",a,{name:"RSA-OAEP",hash:"SHA-256"},!1,["encrypt"])}async function x(t,n,a){const e=await crypto.subtle.generateKey({name:"AES-GCM",length:256},!0,["encrypt","decrypt"]),r=await crypto.subtle.exportKey("raw",e),s=await crypto.subtle.encrypt({name:"RSA-OAEP"},t,r),o=crypto.getRandomValues(new Uint8Array(12)),c=crypto.getRandomValues(new Uint8Array(12)),i=new TextEncoder,l=await crypto.subtle.encrypt({name:"AES-GCM",iv:o},e,i.encode(n)),m=await crypto.subtle.encrypt({name:"AES-GCM",iv:c},e,i.encode(a)),b=JSON.stringify({k:y(s),si:y(o),bi:y(c)});return{subject_encrypted:y(l),body_encrypted:y(m),nonce:b}}async function M(t,n,a,e){const{k:r,si:s,bi:o}=JSON.parse(e),c=await crypto.subtle.decrypt({name:"RSA-OAEP"},t,p(r)),i=await crypto.subtle.importKey("raw",c,{name:"AES-GCM"},!1,["decrypt"]),l=new TextDecoder,m=l.decode(await crypto.subtle.decrypt({name:"AES-GCM",iv:p(s)},i,p(n))),b=l.decode(await crypto.subtle.decrypt({name:"AES-GCM",iv:p(o)},i,p(a)));return{subject:m,body:b}}function y(t){const n=new Uint8Array(t instanceof ArrayBuffer?t:t.buffer??t);let a="";const e=8192;for(let r=0;r<n.length;r+=e)a+=String.fromCharCode.apply(null,n.subarray(r,r+e));return btoa(a)}function p(t){return Uint8Array.from(atob(t),n=>n.charCodeAt(0))}async function A(t,n){const a=new TextEncoder,e=await crypto.subtle.importKey("raw",a.encode(t),{name:"PBKDF2"},!1,["deriveBits","deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:n,iterations:1e5,hash:"SHA-256"},e,{name:"AES-GCM",length:256},!0,["encrypt","decrypt"])}async function j(t,n){const a=await crypto.subtle.exportKey("pkcs8",t),e=crypto.getRandomValues(new Uint8Array(16)),r=crypto.getRandomValues(new Uint8Array(12)),s=await A(n,e),o=await crypto.subtle.encrypt({name:"AES-GCM",iv:r},s,a),c=new Uint8Array(r.length+o.byteLength);return c.set(r,0),c.set(new Uint8Array(o),r.length),{private_key_encrypted:y(c),private_key_salt:y(e)}}async function _(t,n,a){const e=p(t),r=p(n),s=e.slice(0,12),o=e.slice(12),c=await A(a,r),i=await crypto.subtle.decrypt({name:"AES-GCM",iv:s},c,o);return crypto.subtle.importKey("pkcs8",i,{name:"RSA-OAEP",hash:"SHA-256"},!0,["decrypt"])}const D=Object.freeze(Object.defineProperty({__proto__:null,decryptMessage:M,decryptPrivateKey:_,deleteKeyPair:K,encryptMessage:x,encryptPrivateKey:j,exportPublicKeyPem:C,fingerprintPublicKey:v,generateKeyPair:P,importPublicKeyPem:E,loadKeyPair:k,storeKeyPair:S},Symbol.toStringTag,{value:"Module"}));async function H(t,n={}){const a=await f(),e={...n.headers||{}};n.body&&!e["Content-Type"]&&(e["Content-Type"]="application/json"),a&&(e.Authorization=`Bearer ${a}`);const r=await fetch(t,{...n,headers:e});if(!r.ok){let o="API Error";try{const c=await r.json();o=c.error||c.message||o}catch{o=`Status ${r.status}`}throw new Error(o)}const s=r.headers.get("content-type");return s&&s.includes("application/json")?r.json():r.text()}export{L as C,R as L,I as S,O as a,T as b,C as c,M as d,x as e,v as f,P as g,j as h,E as i,_ as j,K as k,H as l,G as m,D as n,S as s};
