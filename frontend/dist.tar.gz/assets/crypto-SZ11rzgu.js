import{c as s}from"./shield-check-COUKzgXV.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=s("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=s("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=s("CircleCheckBig",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=s("CircleX",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=s("LockOpen",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 9.9-1",key:"1mm8w8"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=s("Save",[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=s("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=s("ShieldAlert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]),g="caspmail_e2ee",d="keys";function h(){return new Promise((t,r)=>{const n=indexedDB.open(g,1);n.onupgradeneeded=e=>e.target.result.createObjectStore(d),n.onsuccess=e=>t(e.target.result),n.onerror=()=>r(n.error)})}function w(){return sessionStorage.getItem("caspmail_user_email")||"main"}async function k(t){const r=await h();return new Promise((n,e)=>{const a=r.transaction(d,"readwrite");a.objectStore(d).put(t,w()),a.oncomplete=n,a.onerror=()=>e(a.error)})}async function S(){const t=await h();return new Promise((r,n)=>{const a=t.transaction(d,"readonly").objectStore(d).get(w());a.onsuccess=()=>r(a.result||null),a.onerror=()=>n(a.error)})}async function f(){const t=await h();return new Promise((r,n)=>{const e=t.transaction(d,"readwrite");e.objectStore(d).delete(w()),e.oncomplete=r,e.onerror=()=>n(e.error)})}async function K(){return await crypto.subtle.generateKey({name:"RSA-OAEP",modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:"SHA-256"},!0,["encrypt","decrypt"])}async function C(t){const r=await crypto.subtle.exportKey("spki",t);return`-----BEGIN PUBLIC KEY-----
${btoa(String.fromCharCode(...new Uint8Array(r))).match(/.{1,64}/g).join(`
`)}
-----END PUBLIC KEY-----`}async function v(t){const r=await crypto.subtle.exportKey("spki",t),n=await crypto.subtle.digest("SHA-256",r);return Array.from(new Uint8Array(n)).map(e=>e.toString(16).padStart(2,"0")).join(":").slice(0,47)}async function P(t){const r=t.replace(/-----[^-]+-----/g,"").replace(/\s/g,""),n=Uint8Array.from(atob(r),e=>e.charCodeAt(0));return crypto.subtle.importKey("spki",n,{name:"RSA-OAEP",hash:"SHA-256"},!1,["encrypt"])}async function x(t,r,n){const e=await crypto.subtle.generateKey({name:"AES-GCM",length:256},!0,["encrypt","decrypt"]),a=await crypto.subtle.exportKey("raw",e),y=await crypto.subtle.encrypt({name:"RSA-OAEP"},t,a),o=crypto.getRandomValues(new Uint8Array(12)),c=crypto.getRandomValues(new Uint8Array(12)),i=new TextEncoder,u=await crypto.subtle.encrypt({name:"AES-GCM",iv:o},e,i.encode(r)),m=await crypto.subtle.encrypt({name:"AES-GCM",iv:c},e,i.encode(n)),b=JSON.stringify({k:p(y),si:p(o),bi:p(c)});return{subject_encrypted:p(u),body_encrypted:p(m),nonce:b}}async function E(t,r,n,e){const{k:a,si:y,bi:o}=JSON.parse(e),c=await crypto.subtle.decrypt({name:"RSA-OAEP"},t,l(a)),i=await crypto.subtle.importKey("raw",c,{name:"AES-GCM"},!1,["decrypt"]),u=new TextDecoder,m=u.decode(await crypto.subtle.decrypt({name:"AES-GCM",iv:l(y)},i,l(r))),b=u.decode(await crypto.subtle.decrypt({name:"AES-GCM",iv:l(o)},i,l(n)));return{subject:m,body:b}}function p(t){const r=new Uint8Array(t instanceof ArrayBuffer?t:t.buffer??t);let n="";const e=8192;for(let a=0;a<r.length;a+=e)n+=String.fromCharCode.apply(null,r.subarray(a,a+e));return btoa(n)}function l(t){return Uint8Array.from(atob(t),r=>r.charCodeAt(0))}async function A(t,r){const n=new TextEncoder,e=await crypto.subtle.importKey("raw",n.encode(t),{name:"PBKDF2"},!1,["deriveBits","deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:r,iterations:1e5,hash:"SHA-256"},e,{name:"AES-GCM",length:256},!0,["encrypt","decrypt"])}async function M(t,r){const n=await crypto.subtle.exportKey("pkcs8",t),e=crypto.getRandomValues(new Uint8Array(16)),a=crypto.getRandomValues(new Uint8Array(12)),y=await A(r,e),o=await crypto.subtle.encrypt({name:"AES-GCM",iv:a},y,n),c=new Uint8Array(a.length+o.byteLength);return c.set(a,0),c.set(new Uint8Array(o),a.length),{private_key_encrypted:p(c),private_key_salt:p(e)}}async function _(t,r,n){const e=l(t),a=l(r),y=e.slice(0,12),o=e.slice(12),c=await A(n,a),i=await crypto.subtle.decrypt({name:"AES-GCM",iv:y},c,o);return crypto.subtle.importKey("pkcs8",i,{name:"RSA-OAEP",hash:"SHA-256"},!0,["decrypt"])}const D=Object.freeze(Object.defineProperty({__proto__:null,decryptMessage:E,decryptPrivateKey:_,deleteKeyPair:f,encryptMessage:x,encryptPrivateKey:M,exportPublicKeyPem:C,fingerprintPublicKey:v,generateKeyPair:K,importPublicKeyPem:P,loadKeyPair:S,storeKeyPair:k},Symbol.toStringTag,{value:"Module"}));export{j as C,G as L,z as S,U as a,L as b,O as c,E as d,R as e,V as f,x as g,K as h,P as i,C as j,v as k,M as l,_ as m,f as n,D as o,k as s};
